void errorwrongcasting(int l){
  TypeError = 1;
  cout <<"L. "<<l<<": wrong casting."<< endl;
}

void errorfloor(int l) {
  TypeError = 1;
  cout <<"L. "<<l<<": wrong type for the floor function"<< endl;
}

